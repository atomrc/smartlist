/*global require, define, window*/
/*jslint plusplus: true*/

window.application = (function () {
    'use strict';
    var application = {};

    /***************************************/
    /*************** SERVICES ***************/
    /***************************************/
    application.services = {
    };


    /***************************************/
    /*************** DIRECTIVES ***************/
    /***************************************/
    application.directives = {
        metaContent: function () {
            return {
                restrict: 'A',
                link: function (scope, element, attrs) {
                }
            };
        }
    };

    /***************************************/
    /************* ANIMATIONS **************/
    /***************************************/
    application.animations = {
    };

    /***************************************/
    /*************** CONTROLLERS ***************/
    /***************************************/
    application.controllers = {
        appController: ['$scope', function (scope) {
            scope.todoList = [];
            scope.addElement = function () {
                this.todoList.push({});
            };

            scope.removeElement = function (element) {
                this.todoList.removeElement(element);
            };
        }]
    };

    return application;

}());
